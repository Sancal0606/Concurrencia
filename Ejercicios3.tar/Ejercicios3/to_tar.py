import tarfile 
with tarfile.open('Ejercicios3.tar', 'w') as tar:
    tar.add('Ejercicios3/')